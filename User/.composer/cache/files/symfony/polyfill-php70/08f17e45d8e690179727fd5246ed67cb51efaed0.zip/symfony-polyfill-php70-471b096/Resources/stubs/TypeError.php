<?php

class TypeError extends Error
{
}
