<?php

namespace React\Tests\Cache;

class CallableStub
{
    public function __invoke()
    {
    }
}
