<?php
namespace Ratchet\WebSocket;
use Ratchet\ComponentInterface;

interface MessageComponentInterface extends ComponentInterface, MessageCallableInterface {
}
